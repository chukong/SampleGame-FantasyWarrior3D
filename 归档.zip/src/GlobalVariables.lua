--[[
Global variables
sample:
G.SAMPLE = 20
]]--

G = {};

--Effects


--Player


--3D Part


--Choose Chapter Scene


--Choose Role Scene


--Battlefield Scene


--others


